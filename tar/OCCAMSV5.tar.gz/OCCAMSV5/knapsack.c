/*******************************************************************************/
// Author: SASHKA DAVIS, IDA/CCS
// Date: Feb 7, 2012
//                                                                            //
//  (c) 2012, Institute for Defense Analyses,                                 //
//            4850 Mark Center Drive,                                         //
//             Alexandria, Virginia, 22311-1882;                              //
//             703-845-2500                                                   //
//                                                                            //
// Functionality: A solver for the KNAPSACK problem.
//
// We provide a Dynamic Programming (DP) based Fully polynomial time approximation 
// scheme for the weakly NP-hard problem KNAPSACK. We use the  
// recurense relation for KNAPSACK, see Vijay Vazirani's "Approximation 
// Algorithm'', page 69. If the profits are small the solution is exact. 
//
// The instance is described as an array of Items. Each item has a size, a profit,
// and pp -profit_prime, which is the integer approximatin to the actual profit.
//
// Let Pmax be the maximum profit of any item of the instance.
// Let n be the number of items  in the instance array.
// Let espilon, denoted in the formula as e, be the error in the approximation.
// If the profites are exponential in n, then the error of approximation will be
//   the factor by which we reduce the profits, so that we can allocate a table
//   which fits in the memory.
//
// e is the largest e\in(0,1) such that a table of size (n^2).Pmax.e can fit into 
//   the RAM of the machine. 
// The algorithm finds a solution, which is guaranteed to be within (1-e) of the optimal. 
// If 16.Pmax n^2 bytes can be allocated in memory then the solution is exact.
//
// Let the Instance be the array Items= I[1 .. n].
// Let T be a table with nPmax columns and n rows, then T[k,l] contains the minimum
//     size partial solution whose profit is exactly j, by selecting elements from the set
//     I[1,...k]. The recurrence which describes how table T is populated is:
//
//     For each l=1,..., nPmax, for each i=2,n 
//     T[k+1,l] = MIN{ T[k,l], I_l.size + T[k, l- I_l.size] }, if  I_l.size < l
//              = T[k,l]                                       if  I_l.size >= l
//
//     Initially the table has all cell's size component initialized to INFINITE_SIZE.
//     The first row has all cell's size's set to INFINITE_SIZE, except the cell in
//     column = I[1].pp, will have size = I[1].size.
//
//     There should be a separete note explaining the recurrence from algorithmic
//	perspective.
/*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <math.h>

#include "knapsack.h"

/******************************************************************************/
// Author: SASHKA DAVIS, IDA/CCS
//
// Takes a solution produced by greedy_bmc(), or max_wt_bmc()
//
// sol - must be a computed solution with correct structure
// I - must be a full instance; make sure it is copied from the original other wise
//    there will be SEGFAULT.
// set_lengths - must be an array of costs for each sentence
// term_weights - must be an array of weights of therms.
// We assume that the instance is properly formed. There is no error checking..
//
// 1.We take (I,sol, set_terms, set_lengths, term_weights) and produce
//   an array of Items, with proper profit and size.
//
// 2. Initilizes the parameters of the table tp:
//     num_items
//     num_cols
//     num_cells
//     last_item_id
//     Pmax
/******************************************************************************/
int prepare_items(int n, Table_Params *tp, Item **Items, solution *sol, int **I, int *set_terms, int *set_lengths, float *term_weights)
{

  Item *current_item;
  int num_items;
  int size;
  float profit;
  FILE *data;

  int * current_set;
  int current_num_terms, chosen_set;
  float set_weight;
  int i,j;

    
   if ( (*Items = (Item*)calloc(n, sizeof(Item))) == NULL){
 	printf("\nCouldn't allocate space to store the array (*Items) which");
	printf("\n stores the size and profits of %d items of the instances.", n);
	return(FAIL);
   }
   current_item = *Items;
   num_items = 0; 
   tp->num_items = n;
   tp->Pmax = 0;
   tp->last_item_id = 0;
  
   if(sol->num_chosen >0){ 
      for(i=0; i<sol->num_chosen; i++){
          chosen_set = (sol->chosen_sets)[i];
          current_set = *(I+chosen_set);
          current_num_terms = set_terms[chosen_set];

          set_weight = 0.0;
          for(j=0; j<current_num_terms; j++)
              set_weight += term_weights[current_set[j]];

          current_item->size = set_lengths[chosen_set];
	  current_item->profit = set_weight;

	  if (current_item->profit > tp->Pmax) 
	     tp->Pmax = round(current_item->profit);
          //Uncomment if you need to print while data is being processed.
          //printf("\nItem[%d].profit = %f, Item[%d].size = %d", i, current_item->profit,i,current_item->size  );

	  current_item++;
          num_items++;
      }
   }
   if (tp->Pmax < 1){
	printf("\nERROR: Pmax is smaller than 1. \nUse a different version of knapsack.");
	return(FAIL);
   }
   tp->num_items = num_items;
   tp->last_item_id = num_items-1;
   tp->num_cols = tp->Pmax*tp->num_items;
   tp->num_cells = tp->num_items*tp->num_items;

   return(SUCCESS);
}


/*************************************************************************************/
// Author: SASHKA DAVIS, IDA/CCS
// Print solution assumes that the all table cells are computed properly using
// the knapsack FPTAS algorithm. 
// 
// It scans the last row of tp from right to left, that is from the largest profit
// nPmax, to 1. It seeks to find a knapsack with largest profit whose size is smaller
// than the input requested knapsack size, stored in args->knapsack_size.
/*************************************************************************************/
int print_knapsack_solution(int knapsack_size, int debug, Table_Params *tp, Item *Items, Cell *first)
{

 Cell *curr; 
 int max_profit, row_size,i;
  

  if (first == NULL) return FAIL;
  if(knapsack_size <=0 ) return FAIL;
  if (tp == NULL) return FAIL;

  curr = first + tp->num_cols * tp->num_items - 1;
  max_profit = tp->num_cols;

  printf("\nSOLUTION:");
  for (row_size = tp->num_cols; row_size>0; row_size--){
     if(curr == NULL) return FAIL;
     if(curr->size <= knapsack_size){
        printf("\nKnapsack size=%d  MAX profit=%d",curr->size,max_profit);
	break;
     }
     else{
	if(debug > 0)
            printf("\nNo valide knapsack with profit=%d",max_profit);
     }
     curr--;
     max_profit--;
  }
  printf("\nBEST solution found: Size=%d, Total_Profit=%d",curr->size,max_profit);
  printf("\nItems chosen:");
  for(i=tp->last_item_id; i >= 0; i--){
	if (curr->chosen != NOT_CHOSEN)
	   printf("\n Item_id=%d size=%d, profit=%d",i, Items[i].size, Items[i].pp );

        curr=first+(curr->prev);
        if(curr == NULL) return FAIL;
   }
   printf("\n\n");
   return(SUCCESS);
}//END OF print_solution()


/*******************************************************************************/
// Author: SASHKA DAVIS, IDA/CCS
// Allocates space for the DP table used by the knapsack function.
// Uses the number of items and the max profit Pmax to compute the largest epsilon
// e\in (,1], such that we can mmap a location of n^2.Pmax.e cells.
/*******************************************************************************/
int table_setup(Table_Params *tblPar, Cell **T, Item *Items, int debug)
{
 int delta=0.01;
 int epsilon = 1.0;
 int alloc_success = FAIL;
 int size, i;
 


     if (tblPar == NULL){
        printf("\nERROR: Tabl_Params is NULL.");
	return FAIL;
     }
     if (Items == NULL){ 
        printf("\nERROR: The instance array Items is NULL.");
	return FAIL;
     }
     if(tblPar->num_items <=0){
        printf("\nERROR: TableParam's num_items should be NON-NEGATIVE!");
	return FAIL;
     }
     if(tblPar->Pmax <=0){
        printf("\nERROR: TableParam's Pmax should be NON-NEGATIVE!");
	return FAIL;
     }

     //Allocate space for a table.
     //1. Find the largest size of a table that we can allocate.
     //2. tblPar.size is the number of cells in the 2-D array, which is our DP table.
     //3. Each cell contains 2 integers and 1 char element.
     size = tblPar->num_items * tblPar->num_items * tblPar->Pmax * sizeof(Cell);

     //Try to allocate space for the DP table.
     //Start by attemtping to allocate a table with  n^2Pmax cells,
     //gradually reducing the size until mmap successfully allocates.
     while(alloc_success == FAIL){
        if(((*T)=(Cell*)mmap(NULL,size,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANON,0,0))!=NULL ){
           alloc_success = SUCCESS;
           tblPar->mapped_size = size;
           tblPar->epsilon = epsilon;
           tblPar->num_cols = tblPar->num_items * tblPar->Pmax * epsilon;
           tblPar->num_cells = tblPar->num_cols *  tblPar->num_items;
        }
        epsilon -= delta;
       size = (unsigned long)tblPar->num_items * (unsigned long)tblPar->num_items * (unsigned long)tblPar->Pmax * epsilon * sizeof(Cell);
    }
    if(debug > 0){
       printf("\nTABLE PARAMETERS:");
       printf("\n Pmax=%d", tblPar->Pmax);
       printf("\n num_items=num_rows=%d",tblPar->num_items);
       printf("\n num_cols=%d",tblPar->num_cols);
       printf("\n num_cells=%d",tblPar->num_cells);
       printf("\n sizeof(cell)=%u",(int)sizeof(Cell));
       printf("\n epsilon=%5.3f", tblPar->epsilon);
       printf("\n mapped_size=%u\n",(int)tblPar->mapped_size);
    }
    //If epsilon != 1, then we need to reduce all profits by epsilon;
    //Need to reduce the profits of all items in the instance.
    if(tblPar->epsilon != 1.0){
      printf("\nREDUCING profit precision by a factor of %f and truncating.\n", tblPar->epsilon);
      for(i=0; i<=tblPar->last_item_id; i++)
         (Items[i]).pp = round((Items[i]).profit * tblPar->epsilon);
    }
    else{
        printf("\nTRUNCATION of profits (no reduction is necessary).\n");
        for(i=0; i<=tblPar->last_item_id; i++){
           (Items[i]).pp = trunc((Items[i]).profit);
           if(debug > 0)
              printf("\nItem[%d].profit_prime=%d",i, (Items[i]).pp);
        }
    }
    //****************************************************************
    //Initialize the table. The base case of the recurrence (aka initial conditions).
    // The first row cells have size=INFINITE_SIZE
    // except the column equal to the profit of the first item, that is Items[0].
    //
    // Hence all parital soluztions have size INFINITE_SIZE, except the partial 
    // solution corresponding to elemen of the table[0, item[0].profit].
    //****************************************************************
    if(debug > 0)
        printf("\nINITIALIZATION:");
    int first_item_id = 0;
    int p;
    for(p=0; p < tblPar->num_cols; p++){
       if(Items[first_item_id].pp -1 == p){
          (*T+p)->size = Items[first_item_id].size;
          (*T+p)->chosen = first_item_id;
          if(debug > 0)
             printf("\nChoosing item=%d  profit=%d p_inx=%d", first_item_id, Items[first_item_id].pp,p);
       }
       else{
          (*T+p)->size = INFINITE_SIZE; //there is no solutsion, 
          (*T+p)->chosen = NOT_CHOSEN;
       }
    }
    if(debug > 0)
      printf("\nFinished row=%d", first_item_id );

    //****************************************************************
    //Set the size of the partial solutions to infinity,
    //Initialize the rest of the table, by setting all sizes to INFINITE_SIZE
    //I think this is not necessary
    for(p=tblPar->num_cols; p<tblPar->num_cells; p++){
          (*T+p)->size = INFINITE_SIZE; //there is no solutsion, 
          (*T+p)->chosen = NOT_CHOSEN;
    }
   return(SUCCESS);
}//END OF table_setup()


/********************************************************************************/
// Author: SASHKA DAVIS, IDA/CCS
//The main driver of the FPTAS approximation. 
//
// 1. table_setup() - allocates space for the table T and initializes the first row.
// 2. Each cell in second row (row index 1-num_items -1) is keeps partial solutions according
// to the recurrence 
//     For each l=1,..., nPmax, for each i=2,n 
//     T[k+1,l] = MIN{ T[k,l], I_l.size + T[k, l- I_l.size] }, if  I_l.size < l
//              = T[k,l]                                       if  I_l.size >= l
//
// See a V.Vazirani's "Approximation Algorithms" chapter on Knapsack for further
// clarification.
/********************************************************************************/
int knapsack_fptas(Table_Params *tblPar, Cell **T, Item *Items, int debug)
{
 // Main loop: populate the table of solution using KNAPSACK small profit case 
 //  recurrence, one row at a time 

  int curr_cell = tblPar->num_cols;
  int p_inx=0;
  int p, i;


  //Allocate space for the table.
  // Inilialize the first row of the table, row index 0
  if(table_setup(tblPar, T, Items, debug) != SUCCESS){
	printf("\nERROR: Couldn't allocate space for DP table.");
	return(FAIL);
  }

  if(debug > 0) printf("\nEntering MAIN Loop(s) of the Approximation:");

  //The outer loop iterates through the rows. 
  //We assume row-index 0 is initialized. Rows [1, num_items -1]
  for(i=1; i <= tblPar->last_item_id; i++){
      if(debug > 0)
          printf("\n\nProcessing item=%d,size=%d, profit=%d",i, Items[i].size, Items[i].pp);

      for(p=1; p<=tblPar->num_cols; p++){
         p_inx = p-1;
         //The case when Items[i] element is added to a partial solutions for the first time.
         if( (p == Items[i].pp)  && (  (*T)[(i-1)*tblPar->num_cols +p_inx].size == INFINITE_SIZE)){
             (*T)[curr_cell].chosen = i;
             (*T)[curr_cell].size = Items[i].size;
             if (debug > 0){
                printf("\n  FIRST: Included item=%d, cell=%d, size=%d",i, curr_cell,(*T)[curr_cell].size );
             }
         }
         //
         //A better partial solution is found by adding the current item to the solution.
         if((p>Items[i].pp) && ((*T)[(i-1)*tblPar->num_cols +p_inx].size > (*T)[(i-1)*tblPar->num_cols+p_inx-Items[i].pp].size+Items[i].size)){
               (*T)[curr_cell].chosen = i;
               (*T)[curr_cell].size = (*T)[(i-1)*tblPar->num_cols+p_inx-Items[i].pp].size+Items[i].size;
               (*T)[curr_cell].prev = (i-1)*tblPar->num_cols+p_inx-Items[i].pp ;
               if (debug > 0){
                      printf("\n  DECREASING: including item=%d, cell=%d, new_size=%d,", i, curr_cell, (*T)[curr_cell].size );
               }
         }
         //
         //Adding the current item[i] to the solution does not improve it, so we
         // use the previous row's partial solution.
         else{
                (*T)[curr_cell].size = (*T)[(i-1)*tblPar->num_cols +p_inx].size;
                (*T)[curr_cell].chosen = NOT_CHOSEN;
                (*T)[curr_cell].prev = (i-1)*tblPar->num_cols +p_inx;
                if (debug > 0){
                    printf("\n  COPYING PREVIOUS: not including item=%d, cell=%d, prev_size=%d", i, curr_cell, (*T)[curr_cell].size);
                }
         }//End else - the case when the table is the same as the previoius cell.
      curr_cell++;
      }//End p-driven FOR loop. Finixeshed the i-th row of the table.
  }//End of i-driven FOR loop. The entire table is initialized.

}//END knapsac()

/*************************************************************************************/
// Author: SASHKA DAVIS, IDA/CCS
// Print solution assumes that the all table cells are computed properly  . 
// It scans the last row of tp from right to left, that is from the largest profit
// nPmax, to 1. It seeks to find a knapsack with largest profit whose size is smaller
// than the input requested knapsack size, stored in args->knapsack_size.
/*************************************************************************************/
int make_knapsack_solution(int knapsack_size, int debug, Table_Params *tp, Item *Items, Cell *first, solution *src, solution *dest)
{

 Cell *curr;
 int max_profit, row_size,i;
 int num_chosen;


  if (first == NULL) return FAIL;
  if(knapsack_size <=0 ) return FAIL;
  if (tp == NULL) return FAIL;

  curr = first + tp->num_cols * tp->num_items - 1;
  max_profit = tp->num_cols;

  for (row_size = tp->num_cols; row_size>0; row_size--){
     if(curr == NULL) return FAIL;
     if(curr->size <= knapsack_size){
        //printf("\nKnapsack size=%d  MAX profit=%d",curr->size,max_profit);
        break;
     }
     else{
        if(debug > 0)
            printf("\nNo valide knapsack with profit=%d",max_profit);
     }
     curr--;
     max_profit--;
  }
   //printf("\nBEST solution found: Size=%d, Total_Profit=%d",curr->size,max_profit);
  dest->length = curr->size;
  dest->num_chosen = 0;
  num_chosen = 0;

  // printf("\nItems chosen:");
  for(i=tp->last_item_id; i >= 0; i--){
        if (curr->chosen != NOT_CHOSEN){
           if(debug >0 ) printf("\n Item_id=%d size=%d, profit=%d",i, Items[i].size, Items[i].pp );

           (dest->chosen_sets)[num_chosen]= (src->chosen_sets)[i];

           if(debug >0) printf("\n Sentence: %d is chosen", (dest->chosen_sets)[num_chosen]);

           num_chosen++;           
        }
        curr=first+(curr->prev);
        if(curr == NULL) return FAIL;
   }
   dest->num_chosen = num_chosen;
   // printf("\n Num chosen = %d", dest->num_chosen);
 
   return(SUCCESS);
}//END OF print_solution()


int complete_solution(int **I, solution *sol, int *set_terms,  float *term_weights)
{

int i,j, current_num_terms, *current_set, chosen_set;

   sol->weight = 0;

   if (sol->num_chosen >0){
      for(i=0; i<sol->num_chosen; i++){
          chosen_set = (sol->chosen_sets)[i];
          //Total the weight
          current_set = *(I+chosen_set);
          current_num_terms = set_terms[chosen_set];

          for(j=0; j<current_num_terms; j++){
              if ((sol->terms_covered)[current_set[j]] == COVERED)
                  continue;
              else{
                  (sol->terms_covered)[current_set[j]] = COVERED;
                  sol->weight += term_weights[current_set[j]];
              }
          }
      }
   }
}//END print_solution_sentences()

