/******************************************************************************/
//AUTHOR: Sashka Davis, IDA/CCS                                               //
//Date: Aug 22, 2012                                                          //
//
//                                                                            //
//  (c) 2012, Institute for Defense Analyses,                                 //
//            4850 Mark Center Drive,                                         //
//             Alexandria, Virginia, 22311-1882;                              //
//             703-845-2500                                                   //
//                                                                            //
//OCCAMS ALGORITHM implementation. Details can be found in the paper
//"OCCAMS: An Optimal Combinatorial Covering Algorithm for Multi-document
//Summarization" by S.Davis, J.Conroy, and J.Schlesinger
/******************************************************************************/

#include "knapsack.h"
#define EXTRA_BUDGET 5

int main(int argc, char * const argv[])
{

  char argument_list[] = "z:m:n:s:D:W:L:b:";
  arg_struct args;

//Structures for support of BMC and setcover
  int **sets;		//term-by-sentence matrix, in adjaceny list format...
  int **instance;	//copy of the adjacency list.
  float *term_weights;	//array for the weights of the terms (only non-zero)
			//Populated by read_weights()
  int *set_lengths; 	//array with the lengths of the sentences
			//Populated by read_lengths() 
   int *set_terms;   	//array for the number of non-zero terms of the sentences.  
                        //Populated by read_sets_data() 

   solution S1, S2, S3, S4, S5, *S_ptr;  

  int i; int new_budget;       //usually 5* length of summary 


//Structures for support of KNAPSACK:
  Cell *T;             //DP table with solutions to subproblems 
  Table_Params tblPar; //tblPar - parameters of our table.
                       //size, x,y-dimensions, Pmax, epsilon.
  Item *Items;          //Instance array, for each item we keep size and profit.        
  int debug = -1;      //Set to FALSE




    //Process and parse the command line arguments
    //
    init_args(&args);
    if( parse_arguments(argc, argv, argument_list, &args) == FAIL ){
	exit(1);
    }
    else{
        if((args.data_file==NULL)||(args.weights_file==NULL)||(args.lengths_file==NULL)){
           usage(argv[0]);
           exit(1);
        }
        //print_args(&args);
    }

    //Reading the lengths of the sentences, and the weights of the
    //terms.
    //
    if((set_lengths=read_lengths(&args))==NULL){
	printf("\nERROR: Failed to read the lengths of the sentences.");
        printf("\nExiting with an error.\n");
	exit(1);
    }
    if( (term_weights=read_weights(&args)) ==NULL ){
	printf("\nERROR: Failed to read the weights of the terms in the sentences.");
        printf("\nExiting with an error.\n");
	exit(1);
    }
 
    //Setting up the structure for the support of term-by-sentence 
    // sparce matrix.
    if((sets=(int **)calloc(args.n + 1, sizeof(int *)))==NULL){
       printf("\nERROR: Couldn't allocate memory for sets array.");
       printf("\nExiting with an error.\n");
       exit(1);
    }
    if((set_terms=(int *)calloc(args.n + 1,sizeof(int)))==NULL){
       printf("\nERROR: Couldn't allocate memory for set_terms array.");
        printf("\nExiting with an error.\n");
       exit(1);
    }
    if( read_sets_data(&args, sets, set_lengths, &set_terms) != 0 ){
	printf("\nERROR: Failed to read the data.");
        printf("\nExiting with an error.\n");
	exit(1);
    }

   //Printing what we just read; only in debug mode.
   if(debug > 0){ 
     for (i=1; i<=args.n;i++){
         printf("\n Length of sentence [%d]=%d",i,set_lengths[i]);
     }
     for (i=1; i<=args.m;i++){
         printf("\n weight of term[%d]=%20.10f",i,term_weights[i]);
     }
     printf("\n");
     int *temp_array; int j_th_length; int j;
     printf("\n\nPrinting sets:");
     for(i=FIRST_SET; i<=args.n; i++){
        j_th_length = set_terms[i];  
        temp_array = *(sets+i);
        printf("\nSentence=%d, lenght=%d, num_terms=%d:", i,set_lengths[i], j_th_length);
        for(j=0; j<=j_th_length-1; j++){
           printf(" %d",temp_array[j]);
        }
     }
     printf("\n");
   }//end DEBUG IF
 
    if(set_bound(&args, sets, set_lengths ) == FAIL){ 
	printf("\nERROR: set_bound() failed for S1.");
        printf("\nExiting with an error.\n");
	exit(1);
    }

    //Computing S1 - greedy heuristic for Budgeted Maximal Coverage
    if((instance=(int **)calloc(args.n + 1, sizeof(int *))) == NULL){
        printf("\nERROR: Couldn't allocate memory for sets array.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    if( (memcpy(instance, sets, sizeof(int *)*(args.n+1))) != instance){
	printf("\nERROR: Couldn't create a backup instance.");
        printf("\nExiting with an error.\n");
	exit(1);
    }


    if(init_solution(&S1, &args) == FAIL){
	printf("\nERROR: Failed to initilize S1.");
        printf("\nExiting with an error.\n");
	exit(1);
    }
    budget_max_coverG(instance, &S1, &args, args.summary_length, term_weights, set_lengths, set_terms);
    // Auxiliary printout 
    // printf("\n\nSolution S1:");
    //print_solution(&S1);

    //Computing S2= (max_wt_set) Union (Greedy Budgeted Maximal Coverage on the remaining sets).
    if((memcpy(instance, sets, sizeof(int *)*(args.n+1)))!=instance){
	printf("\nERROR: Couldn't create a backup instance.");
        printf("\nExiting with an error.\n");
	exit(1);
    }
    if(init_solution(&S2, &args) == FAIL){
	printf("\nERROR: Failed to initilize S2.");
        printf("\nExiting with an error.\n");
	exit(1);
    }
    budget_max_coverM(instance, &S2, &args, args.summary_length, term_weights, set_lengths, set_terms);
    //Aux printing
    //printf("\n\nSolution S2: ");
    //print_solution(&S2);

   //Getting the pieces for the KNAPSACK 
   //Computing S3 - greedy heuristic for Budgeted Maximal Coverage 
   // with increase budget for KNAPSACK
    new_budget = args.summary_length * EXTRA_BUDGET;       //usually 5* length of summary
    if((instance=(int **)calloc(args.n + 1, sizeof(int *))) == NULL){
        printf("\nERROR: Couldn't allocate memory for sets array.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    if( (memcpy(instance, sets, sizeof(int *)*(args.n+1))) != instance){
        printf("\nERROR: Couldn't create a backup instance.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    if(init_solution(&S3, &args) == FAIL){
        printf("\nERROR: Failed to initilize S1.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    budget_max_coverG(instance, &S3, &args, new_budget, term_weights, set_lengths, set_terms);
    //Aux printing
    //
    //printf("\n\nSolution S3:");
    // print_solution(&S3);

    //The second piece for the knapsack solution:
    //Computing S4= (max_wt_set) Union (Greedy Budgeted Maximal Coverage on the remaining sets).
    if((memcpy(instance, sets, sizeof(int *)*(args.n+1)))!=instance){
        printf("\nERROR: Couldn't create a backup instance.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    if(init_solution(&S4, &args) == FAIL){
        printf("\nERROR: Failed to initilize S2.\n");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    budget_max_coverM(instance, &S4, &args, new_budget, term_weights, set_lengths, set_terms);
    //Aux printing
    //
    //printf("\n\nSolution S4: ");
    //print_solution(&S4);

    if(S3.weight > S4.weight){
      S_ptr = &(S3);
    }
    else{ 
      S_ptr = &(S4);
    }

  
    if((memcpy(instance, sets, sizeof(int *)*(args.n+1)))!=instance){
        printf("\nERROR: Couldn't create a backup instance.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    //print_solution_sentences(instance, S_ptr, set_terms, set_lengths, term_weights);

    if( prepare_items(S_ptr->num_chosen, &tblPar, &Items, S_ptr, instance, set_terms, set_lengths, term_weights) == FAIL){
        printf("\nERROR:prepare_items(): Could not setup the data structures for knapsack.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    if( knapsack_fptas(&tblPar, &T, Items, debug) == FAIL){
        printf("\nERROR: Knapsack FPTAS engine returned FAIL.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    //Uncomment this code if you need to print the actual knapsack solution
    // which is not mapped to a summary.
    //
    //print_knapsack_solution(args.summary_length, debug, &tblPar, Items, T);

    if((memcpy(instance, sets, sizeof(int *)*(args.n+1)))!=instance){
        printf("\nERROR: Couldn't create a backup instance.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    if(init_solution(&S5, &args) == FAIL){
        printf("\nERROR: Failed to initilize solution S5.");
        printf("\nExiting with an error.\n");
        exit(1);
    }
    make_knapsack_solution(args.summary_length, debug, &tblPar, Items, T, S_ptr, &S5);
    complete_solution(instance, &S5, set_terms, term_weights) ;
    //Aux printing
    //print_solution(&S5);

    

//Choosing the final solution as max cover score of {S1, S2, S5}:
//
    if(S1.weight > S2.weight){
        if(S1.weight >S5.weight){
           printf("\nS1 wins"); 
	   print_solution(&S1);
        }
        else{
           printf("\nS5 wins"); 
	   print_solution(&S5);
        }
    }
    else{ 
        if(S2.weight >S5.weight){
           printf("\nS2 wins"); 
	   print_solution(&S2);
        }
        else{
           printf("\nS5 wins"); 
	   print_solution(&S5);
        }
    }
    printf("\nCleaning up the memory.\n");

   //Free memory of all structures... 
    free(term_weights); 
    free(set_lengths); 
    free(set_terms);
    for (i=1;i<=args.n; i++)
         free(*(sets+i)); 
    free(sets);
    free(instance);
    if (free_solution(&S1) != SUCCESS){
      printf("\nSolution S1 is corrupt");
      exit(1);
    }
    if (free_solution(&S2) != SUCCESS){
      printf("\nSolution S2 is corrupt");
      exit(1);
    }
    if (free_solution(&S3) != SUCCESS){
      printf("\nSolution S3 is corrupt");
      exit(1);
    }
    if (free_solution(&S4) != SUCCESS){
      printf("\nSolution S4 is corrupt");
      exit(1);
    }
    if (free_solution(&S5) != SUCCESS){
      printf("\nSolution S5 is corrupt");
      exit(1);
    }
    //
    //Releasing the dynamic memory
    munmap(T, tblPar.mapped_size);
    free(Items);

    exit(0);


}//END MAIN

