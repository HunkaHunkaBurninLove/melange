/******************************************************************************/
//AUTHOr: Sashka Davis, IDA/CCS                                               //
//Date: Aug 21, 2012                                                          //
//                                                                            //
//  (c) 2012, Institute for Defense Analyses,                                 //
//            4850 Mark Center Drive,                                         //
//             Alexandria, Virginia, 22311-1882;                              //
//             703-845-2500                                                   //
//                                                                            //
//
// Header file for print_cover_only.c
/******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define FIRST_SET	1
//#define DEBUG 		0
//#define DEBUG2 		0
//#define DEBUG3 		0
#define COVERED 	1
#define NOT_COVERED 	0
#define FAIL 		-1
#define SUCCESS 	1

typedef struct SOLUTION solution;
typedef struct ARGS arg_struct;

struct SOLUTION{
	int *chosen_sets;	//ids of the chosen sentences/sets
	int *terms_covered;	//bit mask for terms covered 1-covered; 0-not covered
	int length;		//sum of lengths of chosen sentences
	int num_chosen;
	float weight;		//sum of weights of covered terms
};

struct ARGS{
	int nnz;//The number of non-zeros of the Sentence by terms matrix.
	int m;	//Number of rows of S-T mat, or the number of Terms
	int n;  //Number of sentence of S-T mat.
 	int summary_length; //Bound on the size of the summary.
	char *data_file;    //File describing the S-T matrix in sparce format
	char *weights_file; //File giving the weights of the terms
	char *lengths_file; //File giving the lengths of the terms.
        int lower_bound; //minimal length any sentence selected for summarization must have
        int extra_budget; //minimal length any sentence selected for summarization must have
		//If a person reads the summary longer sentences are preferred.
		//For text mining purposes shorter sences might be ok.
};

int parse_arguments(int argc, char * const argv[], const char *arg_str, arg_struct *args);
int init_solution(solution *sol, arg_struct *args);
int free_solution(solution *sol);
int print_solution(solution *sol);
int print_sentence_ids(solution *so1);
int print_solution_sentences(int **I, solution *sol, int *set_terms, int *set_lengths, float *term_weights);
void usage(char *prg_name);
void print_args(arg_struct *args);
void init_args(arg_struct *args);

int* read_lengths(arg_struct *args);
float* read_weights(arg_struct *args);
int read_sets_data(arg_struct *args, int **sets, int *set_lengths, int **set_terms);

int budget_max_coverG(int **I, solution *sol, arg_struct *args, int sum_length, float *term_weights, int*set_lengths, int *set_terms);
int budget_max_coverM(int **I, solution *sol, arg_struct *args, int sum_length, float *term_weights, int*set_lengths, int *set_terms);
int set_coverG(int **I, solution *sol, arg_struct *args, int target_size, float *term_weights, int*set_lengths, int *set_terms);

int find_best(int **I, solution *sol, int first_set, int instance_size, int *set_terms, float *term_weights, int *set_lengths, int *best_set, int *num_active_sets);
int find_max_wt(int **I, solution *sol, int first_set, int instance_size, int *set_terms, float *term_weights, int *set_lengths, int *best_set, int *num_active_sets);

int set_bound(arg_struct *args, int **sets, int *set_lengths);
