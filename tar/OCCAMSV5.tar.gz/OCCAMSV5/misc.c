/******************************************************************************/
//AUTHOr: Sashka Davis, IDA/CCS                                               //
//Date: Aug 21, 2012                                                          //
//
//                                                                            //
//  (c) 2012, Institute for Defense Analyses,                                 //
//            4850 Mark Center Drive,                                         //
//             Alexandria, Virginia, 22311-1882;                              //
//             703-845-2500                                                   //
//                                                                            //
//Provides implementation of 3 Covering strategies for 2 Covering problems// 
//
//The two problems are Budgented Maximal Coverage and Set Cover problems. Both
// are presumed hard to compute exactly, hence we use approximation schemes.

//In the SET COVER problem, we have a universe of terms T, and a collection of
// sentences, each sentence is a subset of T. Each sentence has a cost. We seek
// to find a solution which is a set of sentences, which covers T, and whose
// combined cost is minimized.
//
//The BUDGED MAXIMAL COVERSAGE problem  (BMCP) is almost the same as the Set Cover problem,
// except we seek to find a set of sentences whose combined cost does not
// exceed a budget L, and which maximizes the sum of the weights of the covered
// terms.
//
//The 3 strategies are used by the OCCAMS algorithm for extractive summarization//
// Details of the algorithm can be found in a paper by S.Davis, J.Conroy and 
// J.Schlesinger "OCCAMS: An Optimal Combinatorial Covering Algorithm for 
// Multi-document Summarization"
//
//
// Strategies for the BUDGETED MAXIMAL COVERAGE PROBLEM:// 
//   1. The first heuristic greedily adds the sets whose normalized 
//      (by the cost)  sum of  
//      weight of uncovered elements is maximized. (budget_max_coverG)        //
//   2. The second heuristic first adds the sets whose weight is maximized.   //
//      Then proceeds like the greedy heuristic.                              //
//   The approximation ratio of choosing best between 1. and 2. for BMCP is   //
//      (1-e^{-2}). The best upper bound, matched by a lower bound uses       //
//       enumeration technique and achieves an approximation ratio of (1-1/e) //
//                                                                            //
// SET COVER PROBLEM                                                          //
//   The greedy heuristic choses the set whose cost of covering new elements  //
//   is minimized. The sets have costs; the elements have profits too.  The   //
//   problem is to select a small number of sets, whose cost is minimal       //
//   subject to the constraint that all elements are covered.                 //
/******************************************************************************/

#include "allcovers.h"

#define DEBUG 0  //Sets the debugging for greedy_bmc and max_Wt_bmc()
#define DEBUG2 0 //Sets the debugging for find_best() and read_data()`
#define DEBUG3 0 //Sets the debugging for the SET COVER algorithm


/******************************************************************************/
//AUTHOR: Sashka Davis, IDA/CCS
// Parse the command line arguments and populate the
// args data structure with file names, length of the summary
// and the dimensions of the term-by-sentense matrix.
/******************************************************************************/

int parse_arguments(int argc, char * const argv[], const char *arg_str, arg_struct *args)
{
  int flag;
  if (argc < 7){
	usage(argv[0]);
	return(FAIL);
  }
  
  args->lower_bound=1;
  args->summary_length=0;
  args->extra_budget=5;
  while ( (flag=getopt(argc, argv, arg_str)) != -1){
    switch(flag){
	case 'e':
		args->extra_budget=atoi(optarg);
	break;

	case 'b':
		args->lower_bound=atoi(optarg);
	break;

	case 'z':
		args->nnz=atoi(optarg);
	break;

	case 's':
		args->summary_length=atoi(optarg);
	break;

	case 'm':
		args->m =atoi(optarg);
	break;

	case 'n':
		args->n =atoi(optarg);
	break;

	case 'D':
		args->data_file=optarg;
	break;

	case 'W':
		args->weights_file=optarg;
	break;

	case 'L':
		args->lengths_file=optarg;
	break;

	default:
		usage(argv[0]);
		return (FAIL);
    }
  }
  if (args->data_file == NULL){
        printf("\nERROR: Must specify name of data file.");
        return(FAIL);
  }
  if (args->weights_file == NULL){
        printf("\nERROR: Must specify name of file with term weights.");
        return(FAIL);
  }
  if (args->lengths_file == NULL){
        printf("\nERROR: Must specify name of file, containing lengths of sentences.");
        return(FAIL);
  }
  if( !args->n || !args->m || !args->nnz){
        printf("\nERROR: NNZ, M, N are numerical values and must be specified!");
        return(FAIL);
  }
  if(args->summary_length == 0){
        printf("\nERROR: Summary length is 0. Nothing to compute.\n") ;
        return(FAIL);
  }
  if((args->extra_budget <= 0) || (args->extra_budget > 100)) {
        printf("\nERROR: Extra budget requested %d is out of bounds [1,100]\n", args->extra_budget) ;
        return(FAIL);
  }
  return(SUCCESS);

}

/***************************************************************************/
//AUTHOR: Sashka Davis
// Prints usage statements, with description of the
// command line arguments. Returns the control to the caller.
/***************************************************************************/

void usage(char *prg_name){
 printf("\n\n %s -z non_zeros -m M -n N -s summary_length -D data_file -W weights_file -L lengths_file -b lower_bound", prg_name); 
 printf("\n   non-zeros is the size of the instance");
 printf("\n   M is the number of terms");
 printf("\n   N is the number of sets");
 printf("\n   summary_length is the length of the summary");
 printf("\n   data_file is the name of the file describing the sets, one pair (set_id, term) per line");
 printf("\n   weights_file is the name of the file containing the non-negative weights of terms, one per line");
 printf("\n   lengths_file is the name of the file lengths of sentences");
 printf("\n   lower_bound is the minimum length a sentence must have in order to be");
 printf("\n      eligable for summarization.");
 printf("\n   ");
 printf("\n\n");
}

/***************************************************************************/
//AUTHOR: Sashka Davis
//Aux. function.
// Prints the values of the command line arguments.
// Does not perform error checking.
/***************************************************************************/

void print_args(arg_struct *args)
{
 printf("\n\nNumber of sentences N=%d", args->n);
 printf("\nNumber of terms M=%d", args->m);
 printf("\nLength of summary L=%d",args->summary_length);
 printf("\nNumber of Non-zeros=%d",args->nnz);
 printf("\nWill read set information from file: %s",args->data_file);
 printf("\nWill read term weights from file: %s",args->weights_file);
 printf("\nWill read sentence weights from file: %s\n",args->lengths_file);
}

/***************************************************************************/
//AUTHOR: Sashka Davis
//
// Initilizes the numeric arguments of the structure args to zero.
// The length of the summary, the number of terms and the number of 
// sentences.
/***************************************************************************/
void init_args(arg_struct *args)
{
 args->m = args->n = args->summary_length = args->nnz = 0 ;
 args->data_file = args->weights_file = args->lengths_file = NULL;
}


/***************************************************************************/
//AUTHOR: Sashka Davis
// Opens the file "arg->lengths_file" for reading and assumes
// that it contains one integer in each line. The i-th line represents
// the length of the i-th sentence.
// The routine does elementary error checking:
//   1. for negative lengths of files
//   2. the number of lines in arg->lengths_file should be equal to arg->n.
//
// BEHAVIOUR:
// Allocates array for the lengths and returns a pointer to the first element
// of the array.
/***************************************************************************/

int* read_lengths(arg_struct *args)
{
 FILE *fd;
 int length;
 int i=0, last_set=0;
 int *set_lengths;
 
   if ( (set_lengths=(int *)calloc(args->n + 1, sizeof(int))) == NULL){
      printf("\nERROR: Couldn't allocate memory for length array.\n");
      return(NULL); 
   }

   if ( (fd=fopen(args->lengths_file, "r")) == NULL ){
      printf("\nERROR opening file: args->lengths_file.\n");
      return(NULL); 
   }

   set_lengths[0]=0;
   while( fscanf(fd, "%d",&length ) != EOF){
      if(length < 0){
         printf("\nERROR: File %s contains a negative length ", args->lengths_file);
         printf(" %d. Lengths cannot be negative!", length);
         return(NULL);
      }
      //Check if the file is longer than -n parameter
      if( i <= args->n){
         i=i+1;
         set_lengths[i]=length;
        //printf("\n Length of sentence [%d]=%d",i,set_lengths[i]);
      }
      else{
        printf("\nThere are more lengths=%d declared than n=%d",i, args->n );
        return(NULL);
     }
   }
   last_set=i;
   fclose(fd);
   if(last_set ==args->n)
       return(set_lengths);
   else{
     printf("\nERROR: Length_file (%s) and N=%d have different lengths\n", args->lengths_file, args->n);
    return(NULL);
   }
}//END read_lengths() 



/***************************************************************************/
// Opens the file "arg->weight_file" for reading and assumes
// that it contains one integer in each line. The i-th line represents
// the weight of the i-th term.
// The routine does elementary error checking:
//    1. for negative lengths of files
//    2. the number of lines in arg->lengths_file should be equal to arg->m
//
// BEHAVIOUR:
// Allocates array for the weights of the terms  and returns a pointer to 
// the first element of the array.
/***************************************************************************/
float* read_weights(arg_struct *args)
{
 FILE *fd;
 float term_weight;
 float *term_weights;
 
    if ( (term_weights=(float *)calloc(args->m + 1, sizeof(float))) == NULL){
       printf("\nERROR: Couldn't allocate memory for weights array\n");
       return(NULL);
    }

    if ( (fd=fopen(args->weights_file, "r")) == NULL ){
       printf("\nERROR: opening file: args->weights_file.\n");
       return(NULL); 
    }
 
    term_weights[0]=0;
    int i=0;
    while( fscanf(fd, "%f",&term_weight ) != EOF){
      i=i+1;
      if(i <= args->m){
         term_weights[i]=term_weight;
         if(term_weight < 0){
             printf("\nERROR: weights_file (%s) has a negative weight term", args->weights_file);
             printf(" %f",term_weight);
            return(NULL);
         }
      }
      else{
	   printf("\nERROR: weight_file(%s) contains ", args->weights_file);
	   printf(" more term weights than %d",args->m);
           return(NULL);
      }
    }

    if(i==args->m)
       return(term_weights);
    else{
       printf("\nERROR: weights_file (%s) and M=%d have different lengths", args->weights_file, args->m);
       return(NULL);
    }
    fclose(fd);
}//END read_terms() 


/***************************************************************************/
// BEHAVIOUR:
// If a length of the sentence is below the lower_boud parameter args->lower_bound
//  Then we dispose of the set and.
/***************************************************************************/
int set_bound(arg_struct *args, int **sets, int *set_lengths)
{
  int i=0;
  int num_short_sentences=0;
  if((set_lengths == NULL) || (sets == NULL)){
     printf("\n sets or set_lengths arrays are corrupted.");
     return(FAIL);
  }
  for(i=1; i<=args->n; i++){
     if (set_lengths[i] < args->lower_bound){
	*(sets+i)=NULL;
        //if(args->DEBUG)
        printf("\nSentence %d has length %d and is shorter than the lower bound=%d.", i, set_lengths[i], args->lower_bound);
        num_short_sentences++;
     }
  }
  printf("Number of short sentences is %d",  num_short_sentences);
  return(SUCCESS);
}

/***************************************************************************/
// BEHAVIOUR:
// Opens a file pointed by args->data_file, which should contain pairs of 
// Sentence ID, Term ID, one per line. 
// data_file describes the term-by-sentence matrix in sparce format.
// read_sets_data() populates the sets array such that the i-th element
//   points to an array of integers describing the i-th sentence, S_i.
// read_sets_data() also modifies the set_terms: the i-th element represents
//   the size of |S_i|, or the number of terms in it.
/***************************************************************************/
int read_sets_data(arg_struct *args, int **sets, int *set_lengths, int **set_terms)
{
 FILE *fd;
 int set_id, term, *temp_array, i, j, j_th_length;
 int current_set, current_set_length, current_set_max_length, *set_array, instance_size;
 
  
    if ( (temp_array=(int *)calloc(args->m + 1, sizeof(int))) == NULL){
       printf("\nERROR: Couldn't allocate memory for temp_array\n");
       return(FAIL);
    }

    if ( (fd=fopen(args->data_file, "r")) == NULL ){
       printf("\nERROR: opening file: args->data_file.\n");
       return(FAIL); 
    }

 /* Set  up the first set */
    set_id=FIRST_SET;
    current_set=FIRST_SET;
    current_set_max_length = set_lengths[current_set];
    if (DEBUG)
	    printf("\n%d-st length is %d", current_set,current_set_max_length);

    current_set_length=0;
    instance_size=0;

/* Main loop: 
	1) Read a pair; 
	2) If the ID is new then we finilize the old set
		- clean up temp storage for the new set.
*/
    while( fscanf(fd, "%d %d",&set_id, &term ) != EOF){
       if ((set_id <= 0) || (term<= 0)){
	 printf("\nERROR: File %s has a pair (%d %d). Both should be greater than 0",args->data_file, set_id, term);
         return(FAIL);
       }
       if(current_set > args->n){
 	printf("\nERROR: File %s contains a sentence with id=%d > max_id=%d", args->data_file, set_id, args->n);
        return(FAIL);
       }
       if(set_id != current_set){ 
       /* current_set is finished; create the structure to hold the set. */
       /*update sets array*/
          if( (set_array = (int *) calloc(current_set_length, sizeof(int))) == NULL){
	     printf("\n ERROR: couldn't allocate memory to hold the %d-th set", set_id);
 	     return(FAIL);
          }
          if( (memcpy(set_array,temp_array, sizeof(int)*current_set_length)) != set_array){
 	     printf("\n ERROR: couldn't copy temp_array to set_array");
 	     return(FAIL);
          }
          sets[current_set]=set_array;
          *((*set_terms)+current_set)=current_set_length;
          /* Set the information for the new set */
           current_set = set_id;
           current_set_max_length = set_lengths[current_set];
           current_set_length = 0;
       } 
       /*process the current pair check if size of the set agrees with the length of the set .. before adding it*/
       if(current_set_length <= current_set_max_length){
          temp_array[current_set_length] = term;
          current_set_length++;
          instance_size++;

	  if(DEBUG2) printf("\n Read %d %d", set_id, term);
       } 
       else{
           printf("\nSentence %d has more terms than the declared length of %d.",current_set, current_set_max_length);
           return (FAIL);
       }
       if(instance_size > args->nnz){
 	  printf("\nData in file: %s exceeds the NNZ=%d", args->data_file, args->nnz);
 	  return(FAIL);
       }
    }//END OF WHILE 
 //Processing the last set.
  if((set_array = (int *) calloc(current_set_length, sizeof(int))) == NULL){
 	printf("\n ERROR: couldn't allocate memory to hold the %d-th set", set_id);
 	return(FAIL);
  }
  if((memcpy(set_array,temp_array, sizeof(int)*current_set_length)) != set_array){
	printf("\n ERROR: couldn't copy temp_array to set_array");
 	return(FAIL);
  }
  sets[current_set]=set_array;
  *((*set_terms)+current_set)=current_set_length;

  free(temp_array);
  fclose(fd);
  return(0);
}//END read_data_sets()

/***************************************************************************/
//Initializes an empty solution.
// Sets counters to 0 and allocates memory for 
// the IDs of chosen sets and covered terms.
/***************************************************************************/
int init_solution(solution *sol, arg_struct *args)
{
 sol->weight = 0.0;
 sol->num_chosen = 0;
 sol->length = 0;
 if( (sol->chosen_sets=calloc(args->n+1, sizeof(int)))==NULL){
	printf("\nERROR: can't allocate solution's chosen sets array");
	return(FAIL);
 }
 if( (sol->terms_covered=calloc(args->m+1, sizeof(int)))==NULL){
	printf("\nERROR: can't allocate solution's covered terms array");
	return(FAIL);
 }
 return(0);
}

/***************************************************************************/
// Frees memory allocated by the solution.                                 //
/***************************************************************************/
int free_solution(solution *sol)
{
   if(sol == NULL)
      return (FAIL);
   free(sol->chosen_sets);
   free(sol->terms_covered);
   return(SUCCESS);
}

/***************************************************************************/
//Prints solution statistics and                                           //
//the ids of the sentences/sets chosen.                                    //
/***************************************************************************/
int print_solution(solution *sol)
{
 int i;
 
   printf("\nSummary length=%d",sol->length);
   printf("\nNumber of chosen sets=%d",sol->num_chosen);
   printf("\nCover weight=%f",sol->weight);
 
   if (sol->num_chosen >0){
      printf("\nChosen sentences: ");
      for(i=0; i<sol->num_chosen; i++)
        printf("%d ",(sol->chosen_sets)[i]);
   }
}//END print_solution()

/***************************************************************************/
//Prints solution statistics.                                              //
//   Print the IDs of the sentences/sets chosen.                           //
/***************************************************************************/
int print_sentence_ids(solution *sol)
{
 int i;
 
   if (sol == NULL){
	printf("\nThere is a problem..");
	exit(1);
   }
   if (sol->num_chosen >0){
     // printf("\nChosen sentences: ");
      for(i=0; i<sol->num_chosen; i++)
        printf("%d ",(sol->chosen_sets)[i]);
   }
   printf("\n");
}//END print_solution()


/***************************************************************************/
//Prints solution statistics.                                              //
//   Print the IDs of the sentences/sets chosen.                           //
//   Print for each setntence its weight and length                        //
/***************************************************************************/
int print_solution_sentences(int **I, solution *sol, int *set_terms, int *set_lengths, float *term_weights)
{
 int i,j, current_num_terms, *current_set,set_length, chosen_set;
 float set_weight;

   if (sol->num_chosen >0){
      for(i=0; i<sol->num_chosen; i++){
          chosen_set = (sol->chosen_sets)[i];
          //Total the weight
          current_set = *(I+chosen_set);
          current_num_terms = set_terms[chosen_set];
          set_length=set_lengths[chosen_set];
          set_weight = 0.0;
          for(j=0; j<current_num_terms; j++)
              set_weight += term_weights[current_set[j]];

          printf("\n%d ",(sol->chosen_sets)[i]);
          printf("%d %f", set_length, set_weight);
      }
   }
}//END print_solution_sentences()

/*****************************************************************************/
//Computes a solution to the Budgeted Maximal Coverage problem using the     // 
//  the  greedy heuristic: add the sentence whose normalized sum of weights  //
//  of uncovered term is the highest.                                        //
//                                                                           //
//ARGUMENTS:                                                                 //
// I  - points to array of pointers. Each member of the array describes one
//      set(sentence). The actual sets (sentences) are not modified, but I is modified
//      once a sentence is added to the solution, the pointer in I which refers to it
//      is set to NULL
// size - the dimension of I.
// set_terms - is array describing the length of each set pointed by I
//      not modified.
// set_lengths - array describing the cost of sets or lengths of sentences.
//      not modified.
// sol - initially empty solution, whose sets of chosen_sets, terms_covered 
//      and length are updated as sets are added to solution.
// sum_length - the budget or the number of words in the summary.
// term_weights, whose i-th element describes the weight of the i-th term.
// debug - flag if set to DEBUG will cause a verbose output
//
// BEHAVIOUR:
//  Implements the greedy heuristic for the BMCP. Proceeds in iteration and
//  at each iteration selects the "best" sentence and adds it to the solution sol.
//  "best" is the sentence whose sum of weights of uncovered by sol terms normalized
//  by the cost of the sentence is maximized.
//                                                                           // 
/*****************************************************************************/
int budget_max_coverG(int **I, solution *sol, arg_struct *args, int sum_length, float *term_weights, int*set_lengths, int *set_terms)
{
 int best_set, instance_size, *current_set, current_length, current_terms;
 int i,j, num_active_sets;  //num_active sets - the number of active sets in the instance

   instance_size = args->n; 
   best_set=0; //This is invalid, as the set IDs are positive.

   //Find the most cost effective set.
   num_active_sets = 0;
   if(find_best(I,sol,FIRST_SET,instance_size,set_terms,term_weights,set_lengths,&best_set,&num_active_sets)==FAIL){
	printf("\nERROR: finding the best set");
	return(FAIL);
   }
   if(DEBUG){
	printf("\n Num_active_sets = %d, Best_id = %d", num_active_sets,best_set);
   }
   while((num_active_sets >0) && (sol->length <= sum_length)){
       if(DEBUG) printf("\n\nNew Iteration:");
       //Add the most cost effective set to the solution
       // if it fits in the solution
       current_set = *(I+best_set);
       current_terms=set_terms[best_set];
       current_length=set_lengths[best_set];
       if(current_length <= sum_length - sol->length){
         (sol->chosen_sets)[sol->num_chosen] = best_set;
         sol->num_chosen++;
         sol->length += current_length;
         for(j=0; j<current_terms;j++){
            if((sol->terms_covered)[current_set[j]] != COVERED){
	       (sol->terms_covered)[current_set[j]] = COVERED;
	       sol->weight+=term_weights[current_set[j]];
            }                
         }
         if(DEBUG){
            printf("\n  Will add set=%d, length=%d, sum_len=%d",best_set, current_length,sol->length );
	    printf("\n Num_active_sets = %d, Best_id = %d", num_active_sets,best_set);
         }
       }
       //Make the current-best set in-active.
       *(I+best_set) = NULL; 
       //Find the next most cost-effective set,
       num_active_sets = 0;
       best_set = 0;
       if(find_best(I,sol,FIRST_SET,instance_size,set_terms,term_weights,set_lengths,&best_set,&num_active_sets)==FAIL){
	 printf("\nERROR: finding the best set");
	 return(FAIL);
      }
 }//END while
}//END budget_max_coverG()

/***************************************************************************/
//Computes a solution to the Budgeted Maximal Coverage problem, which includes
// first the heaviest weight sentence.
//
//ARGUMENTS:
// I  - points to array of pointers. Each member of the array describes one
//      set(sentence). The actual sets (sentences) are not modified, but I is modified
//      once a sentence is added to the solution, the pointer in I which refers to it
//      is set to NULL
// size - the dimension of I.
// set_terms - is array describing the length of each set pointed by I
//      not modified.
// set_lengths - array describing the cost of sets or lengths of sentences.
//      not modified.
// sol - initially empty solution, whose sets of chosen_sets, terms_covered 
//      and length are updated as sets are added to solution.
// sum_length - the budget or the number of words in the summary.
// term_weights, whose i-th element describes the weight of the i-th term.
//
// BEHAVIOUR:
// The algorithm selects the sentence with the highest weight first and then
//      other "best" sentences, as long as the combined lenght of sentences
//      selected does not exceed sum_length.
// 
/***************************************************************************/
int budget_max_coverM(int **I, solution *sol, arg_struct *args, int sum_length, float *term_weights, int*set_lengths, int *set_terms)
{
 int best_set, instance_size, *current_set, current_length, current_terms;
 int i,j, num_active_sets;


   instance_size = args->n; 
   best_set=0;

   //Find the heaviest weight set - the id is stored in best_set.
   num_active_sets = 0;
   if(find_max_wt(I,sol,FIRST_SET,instance_size,set_terms,term_weights,set_lengths,&best_set,&num_active_sets)==FAIL){
      printf("\nERROR: finding the highest weight set");
      return(FAIL);
   }
   if(DEBUG){
      printf("\n Num_active_sets = %d, Best_id = %d", num_active_sets,best_set);
   }

   while((num_active_sets >0) && (sol->length <= sum_length)){
      if(DEBUG) printf("\n\nNew Iteration:");
      //Add the best set (best_set)to the solution.
      //Update the solution.
      current_set = *(I+best_set);
      current_terms=set_terms[best_set];
      current_length=set_lengths[best_set];
      if(current_length <= sum_length - sol->length){
         (sol->chosen_sets)[sol->num_chosen] = best_set;
         sol->num_chosen++;
         sol->length += current_length;
         for(j=0; j<current_terms;j++){
            if((sol->terms_covered)[current_set[j]] != COVERED){
	       (sol->terms_covered)[current_set[j]] = COVERED;
	       sol->weight+=term_weights[current_set[j]];
            }                
         }
         if(DEBUG){
            printf("\n  Will add set=%d, length=%d, sum_len=%d",best_set, current_length,sol->length );
	    printf("\n Num_active_sets = %d, Best_id = %d", num_active_sets,best_set);
         }
      }
      *(I+best_set) = NULL; 
     //
      num_active_sets = 0; //should be updated by find_best; num_active_sets should be 
      //the number of non-NULL ponters in I.
      best_set = 0;
      if(find_best(I,sol,FIRST_SET,instance_size,set_terms,term_weights,set_lengths,&best_set,&num_active_sets)==FAIL){
	 printf("\nERROR: finding the best set");
	 return(FAIL);
      }
 }//END while
}

/**************************************************************************/
// Implementation of the classic Greedy apprximation scheme for the set cover
//  problem. See V.Vazirani's "Approximation Algorithms", Ch.2 for details and
//  analysis. Briefly, the algorithm is iterative and at each iteration the
//  most cost effective set is chosen and added to the solution. The algorithm
//  terminates when the collection of shosen sets covers the universe of items.
//
//ARGUMENTS:
//     m - the size of the universe that must be covered.
//     n - the size of the instance, the number of elements in I
//     I - is the instance, or term-by-sentence matrix  transposed
//         I points to arrays for each S_i, i=1,..,n
//         the 0 index is unused for matlab compatability.
//     set_lengths - the cost function, here, the lengths of the sentences
//     set_terms - an array with sizes of the sets S_i, or the number
//        of terms in S_i
//     debug - flag, if set to DEBUG will cause verbose output.
//
/**************************************************************************/
int set_coverG(int **I, solution *sol, arg_struct *args, int target_size, float *term_weights, int*set_lengths, int *set_terms)
{
 int best_set, instance_size, *current_set, current_length, current_terms;
 int i,j, num_active_sets;  //num_active sets - the number of active sets in the instance
 int current_size_of_cover;


   instance_size = args->n;
   best_set=0; //This is set to invalid value; as the set IDs are positive.
   num_active_sets = 0;
   //Find the most cost effective set - the id is stored in best_set;
   if(find_best(I, sol, FIRST_SET, instance_size, set_terms, term_weights, set_lengths, &best_set, &num_active_sets)== FAIL){
       printf("\nERROR: finding the best set");
       return(FAIL);
   }
   if(DEBUG3)
        printf("\n Num_active_sets = %d, Best_id = %d", num_active_sets,best_set);
  
   current_size_of_cover = 0;
   //args->m contains the total number of terms, all should be covered at the end
   while(current_size_of_cover < target_size){
      if(DEBUG3) printf("\nNew Iteration:");
      //Add best to solution to the cover
      current_set = *(I+best_set);
      if(current_set != NULL){
         current_terms=set_terms[best_set];
         current_length=set_lengths[best_set];
         (sol->chosen_sets)[sol->num_chosen] = best_set;
         sol->num_chosen++;
         sol->length += current_length;
         for(j=0; j<current_terms;j++){
            if((sol->terms_covered)[current_set[j]] != COVERED){
               (sol->terms_covered)[current_set[j]] = COVERED;
	       sol->weight+=term_weights[current_set[j]];
               current_size_of_cover++;
            }                
         }
         if(DEBUG3){
            printf(" Adding set=%d",best_set);
            printf(" Num_active_sets=%d", num_active_sets);
            printf("curr_cover_size=%d", current_size_of_cover);
         }
      //Remove the set from the active sets. 
      }
      else{
         printf("\nInvalid set. ");
	 if(num_active_sets == 0){
            printf("No more active sets. Terms to cover=%d; covered=%d only.", target_size, current_size_of_cover);
            print_solution(sol);
            int k;
            for(k=1; k<=args->m ;k++)
               if((sol->terms_covered)[k] == NOT_COVERED)
                  printf("\n NOT COVERED: %d", k);
            }
         return(FAIL);
      }
      *(I+best_set) = NULL;
      //Find the next cost effective set.
      best_set = 0;
      num_active_sets = 0;
      if(find_best(I, sol, FIRST_SET, instance_size, set_terms, term_weights, set_lengths, &best_set, &num_active_sets) != SUCCESS){
         printf("\nERROR: finding the best set");
         return(FAIL);
      }
 }//END while

}

/*****************************************************************************/
//Author: Sashka Davis, IDA/CCS
//
// Auxiliary function, used both by the Greedy algorithm for set cover
// and by the greedy routine for the Budgeted Maximal Coverage problem.     
// Implements the "greedy" choise.
//
// BEHAVIOUR:
// It finds the best, not yet chosen set from the instance, whose average sum of 
//   weights of elements in that set, yet covered by the partial solution.
//   remaining sets is maximal       
// 
// Searches from non NULL sets pointed by I the one whose average profit     
// is the best. The profit of the set is the sum of the weights covered     
// Average is computed by dividing the profit of the set by its cost, here  
// we use length as such.                                                   
//
// ARGUMENTS:
// I  - points to array of pointers. Each member of the array describes one
//      set(sentence). The actual sets (sentences) are not modified, but I is modified
//      once a sentence is added to the solution, the pointer in I which refers to it
//      is set to NULL
// size - the dimension of I.
// set_terms - is array describing the length of each set pointed by I
//      not modified.
// set_lengths - array describing the cost of sets or lengths of sentences.
//      not modified.
// sol - initially empty solution, whose sets of chosen_sets, terms_covered 
//      and length are updated as sets are added to solution.
// sum_length - the budget or the number of words in the summary.
// term_weights, whose i-th element describes the weight of the i-th term.
/*****************************************************************************/
int find_best(int **I, solution *sol, int first_set, int instance_size, int *set_terms, float *term_weights, int *set_lengths, int *best_set, int *num_active_sets)
{
 int i,j;
 float current_wt, norm_wt, best_wt;
 int current_length, current_terms;
 int *current_set;

   if((first_set < 0) || (instance_size <=0)){
      printf("\nERROR: find_best() is called with instance of size 0!");
      return (FAIL);
   }
   best_wt = 0.0;
   for(i=first_set; i<=instance_size; i++){
        current_set = *(I+i);
        current_wt = 0.0;
        norm_wt = 0.0;
	//
 	//Check if the set is still active.
        if(current_set != NULL){
           current_length=set_lengths[i];
           current_terms=set_terms[i];
           for(j=0; j<current_terms; j++){
              if((sol->terms_covered)[current_set[j]]== NOT_COVERED)
                 current_wt+=term_weights[current_set[j]];
           }
           norm_wt = current_wt / (float)set_lengths[i];
           if(DEBUG2){
              printf("\n Set[%d]'s length is %d; #terms=%d", i,current_length, current_terms);
              printf(";wt=%7.3f, norm.wt=%7.3f", current_wt,norm_wt);
           }
           if(current_wt > 0)
              (*num_active_sets)++;
           else{ 
              *(I+i) = NULL;
           }
           if(norm_wt > best_wt){
              if (DEBUG2) printf("\nFoud a new best set: %d", i);
              *best_set=i;
              best_wt=norm_wt;
           }
        }//END if SET IS STILL ACTIVE
   }//END FOR
   return(SUCCESS);
}//END find_best()


/*****************************************************************************/
//Author: Sashka Davis, IDA/CCS
// Auxiliary function (but crusial), used by BMC algorithm.                  //
// Finds the sentence whose combined weights of terms is the maximum.        //
//
// ARGUMENTS:
// I  - points to array of pointers. Each member of the array describes one
//      set(sentence). The actual sets (sentences) are not modified, but I is modified
//      once a sentence is added to the solution, the pointer in I which refers to it
//      is set to NULL
// size - the dimension of I.
// set_terms - is array describing the length of each set pointed by I
//      not modified.
// set_lengths - array describing the cost of sets or lengths of sentences.
//      not modified.
// sol - initially empty solution, whose sets of chosen_sets, terms_covered 
//      and length are updated as sets are added to solution.
// sum_length - the budget or the number of words in the summary.
// term_weights, whose i-th element describes the weight of the i-th term.
// debug - flag if set to DEBUG will cause a verbose output
// best_set - an OUT variable, and upon exit points to the "best" active set found.
// num_active_sets - counter for the number of remaining active sets in 
//         the instance I
// A set "i" is active if (*I+i) is NOT NULL. 
//
// BEHAVIOUR:
// Searches from non NULL sets pointed by I the one whose profit is maximal  //
// The profit of the set is the  sum of the weights covered                  //
// The id of the best set is recorded in *best_set.                          //
// Num_active_sets is updated - these are the number of non-NULL sets in I.  //
/*****************************************************************************/
int find_max_wt(int **I, solution *sol, int first_set, int instance_size, int *set_terms, float *term_weights, int *set_lengths, int *best_set, int *num_active_sets)
{
 int i,j;
 float current_wt, best_wt;
 int current_length, current_terms;
 int *current_set;

   if((first_set < 0) || (instance_size <=0)){
      printf("\nERROR: find_max_wt() is called with instance of size 0!");
      return (FAIL);
   }
   best_wt = 0.0;
   for(i=first_set; i<=instance_size; i++){
        current_set = *(I+i);
        current_wt = 0.0;
	//
 	//Check if the set is still active.
	//Work on active sets only.
        if(current_set != NULL){
           current_length=set_lengths[i];
           current_terms=set_terms[i];
           for(j=0; j<current_terms; j++){
              if((sol->terms_covered)[current_set[j]]==NOT_COVERED)
                 current_wt+=term_weights[current_set[j]];
           }
           if(DEBUG2){
              printf("\n Set[%d]'s length is %d; #terms=%d", i,current_length, current_terms);
              printf(";wt=%7.3f", current_wt);
           }
           if(current_wt > 0)
              (*num_active_sets)++;
           else
               *(I+i) = NULL;
           if(current_wt>best_wt){
              if (DEBUG2) printf("\nFoud a new best set: %d", i);
              *best_set=i;
               best_wt=current_wt;
           }
        }//end IF set is still active
   }//end FOR
   return(SUCCESS);
}//END find_max_wt()
