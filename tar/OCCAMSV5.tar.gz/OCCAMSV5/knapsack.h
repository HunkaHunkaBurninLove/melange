/**************************************************************************/
//Author: Sashka Davis, IDA/CCS
//Date: Feb. 14, 2012
//                                                                            //
//  (c) 2012, Institute for Defense Analyses,                                 //
//            4850 Mark Center Drive,                                         //
//             Alexandria, Virginia, 22311-1882;                              //
//             703-845-2500                                                   //
//                                                                            //
//Header file with declarations and type definitions used by knapsack.c
/**************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <math.h>


#define INFINITE_SIZE 10000
#define FAIL -1
#define TRUE 1
#define FALSE 0
#define NOT_CHOSEN -1


typedef struct Item Item;
typedef struct Cell Cell;
typedef struct Table_Params Table_Params;

#include "allcovers.h"

//****************************************************************
// type "item" is used to encode the elements of the instance. 
// We allocate an array of items. 
// For each we keep the size and the profit.
//****************************************************************
struct Item{
        int size;
        float profit;	//The exact profit of the item.
	int pp;		//profit_prime - the rounded integer version of profit
};

/*******************************************************************************/
//Type "cell" is used for the cells of the DP table.
// Each cell holds partial solutions to the recurence.
// The meaning of a cell, cell[i,j] is as follows:
//     cell[i,j] holds the minimum size knapsack of profit j, which is 
//     calculated from items 1,..., i-1. 
//     "size" keeps the actual size of the partial solution. 
//     "chosen" indicates whether the i-th item is added to the knapsack or not.
//         chosen == TRUE then the i'th item is added to the knapsack
//         chosen == FALSE then the i'th item is not added
//     "previous" gives the ID as a position in the table of the previous???
//*******************************************************************************/
struct Cell{
        int size;       //the size of the partial knapsack at this cell.
        int chosen;	//Flag indicating whether the item was added to the solution
                        // or not. If the item is added to the solution, then the 
                        // belogs = '1', otherwise, belogns = '0'.
        int prev;   	//The index of the previous item considered. From the
                        //recurrence.
};
//*******************************************************************************/
// Strucuture containing the parameters for the DP table, the number of rows and columns
// The number of rows is equal to the the  number of items num_items
// The number of columns, num_columns, depends on number of items, maximum profit size, 
//*******************************************************************************/
struct Table_Params{
        int Pmax;       //The maximum weight an item in the instance
        int num_items;  //Number of items - number of rows of the table
        int num_cols; //n*Pmax*epsilon - rounded to the nearest integer.
        int num_cells;   //(num_items^2 * Pmax * epsilon)
        size_t mapped_size;//The actual size of the table in Bytes
			// This amount is needed for unmap() call.
        float epsilon;  // The error of approximation
        int last_item_id;//The id of the last item (num_items -1) - usually.
};


int prepare_items( int n, Table_Params *tp, Item **Items, solution *sol, int **I, int *set_terms, int * set_lengths, float *term_weights);
int table_setup(Table_Params *tblPar, Cell **T, Item *Items, int debug);
int knapsack_fptas(Table_Params *tblPar, Cell **T, Item *Items, int debug);
int print_knapsack_solution(int knapsack_size, int debug, Table_Params *tp, Item *Items, Cell *first);
int make_knapsack_solution(int knapsack_size, int debug, Table_Params *tp, Item *Items, Cell *first, solution *src, solution *dest);
int complete_solution(int **I, solution *sol, int *set_terms,  float *term_weights);

